/**
*  @author      Samuel You
*  @ID          b08505018
*  @Department  Engineering Science and Ocean Engineering
*  @Affiliation National Taiwan University
*/

#include <iostream>

using namespace std;

bool isMultiple(long n, long m){
    if (n % m == 0){
        return true;
    }
    else{
        return false;
    }
};